$(document).ready(function() {
    // Get value on button click and show alert
    $("#myBtn").click(function() {
        var firstname = $("#firstname").val();
        var lastname = $("#lastname").val();
        var email = $("#email").val();
        var course = $("#course").text();
        var phone = $("#phone").val();
        var message = $('textarea#message').val();
        if (firstname == "") {
            $("#datamsg").text("Enter your first name");
            $("#datamsg").show();
        } else if (email == "") {
            $("#datamsg").text("Enter your email");
            $("#datamsg").show();
        } else if (course == "") {
            $("#datamsg").text("Enter your course");
            $("#datamsg").show();
        } else if (message == "") {
            $("#datamsg").text("Enter your message");
            $("#datamsg").show();
        } else if (phone == "") {
            $("#datamsg").text("Enter your phone number");
            $("#datamsg").show();
        } else {
            var myurl = "https://op2kzznfje.execute-api.us-east-1.amazonaws.com/v1/quote";
            var mydata = {
                "first_name": firstname,
                "last_name": lastname,
                "email": email,
                "course": course,
                "phone": phone,
                "message": message
            }
            $.ajax({
                url: myurl,
                data: JSON.stringify(mydata),
                headers: {
                    "content-type": "application/json"
                },
                method: "POST",
                success: function(data) {
                    $("#datamsg").text('We will get in touch with you very soon');
                    $("#datamsg").show();
                    $("form")[0].reset();
                }
            })
        }
    })
})