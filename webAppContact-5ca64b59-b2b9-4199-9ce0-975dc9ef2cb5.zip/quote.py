import json
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)
import boto3
dynamodb = boto3.resource('dynamodb')

table = dynamodb.Table("quote")

def lambda_handler(event, context):
    http_method = event.get('httpMethod')
    if http_method == 'POST':
        body = event.get('body')
        first_name = ''
        last_name = ''
        email = ''
        course = ''
        phone = ''
        message = ''
        if body is not None:
            first_name = json.loads(body).get('first_name', first_name)
            last_name = json.loads(body).get('last_name', last_name)
            email = json.loads(body).get('email', email)
            course = json.loads(body).get('course', course)
            phone = json.loads(body).get('phone', phone)
            message = json.loads(body).get('message', message)
            
            res_items = {
                "first_name" : first_name,
                "last_name" : last_name,
                "email" : email,
                "course" : course,
                "phone" : phone,
                "message" : message
            }
            try:
                table.put_item(Item=res_items)
                logger.info(" Data inserted successfully")
            except Exception as e:
                logger.info("Couldn't insert data into table")
            response = {
                    "isBase64Encoded": False,
                    "statusCode": 200,
                    "body": json.dumps({'msg':'Data inserted successfully'}),
                    "headers": {
                        'Content-Type' : 'application/json',
                        'Access-Control-Allow-Origin' : '*',
                        'Allow' : 'POST',
                        'Access-Control-Allow-Methods' : 'POST',
                        'Access-Control-Allow-Headers' : '*'
                        }
                }
        else:
            response = {
                    "isBase64Encoded": False,
                    "statusCode": 400,
                    "body": json.dumps({'msg':'Body is not none'}),
                    "headers": {
                        'Content-Type' : 'application/json',
                        'Access-Control-Allow-Origin' : '*',
                        'Allow' : 'POST',
                        'Access-Control-Allow-Methods' : 'POST',
                        'Access-Control-Allow-Headers' : '*'
                        }
                }
    return response
        
            
            
            